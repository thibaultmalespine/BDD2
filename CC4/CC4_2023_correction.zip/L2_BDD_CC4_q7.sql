DROP FUNCTION F_question7();
DROP TYPE retour;
CREATE TYPE retour AS(e1 VARCHAR(40),e2 VARCHAR(40));

CREATE FUNCTION F_question7(uneJ INT) 
RETURNS SETOF retour AS $$
DECLARE
	res retour;
BEGIN
	FOR res IN SELECT equipe1, equipe2
	FROM Matchs
	WHERE uneJournee = uneJ
	LOOP
		RETURN NEXT res;
	END LOOP;
	RETURN;
END; $$LANGUAGE 'plpgsql';

-- on vide les tables avant les tests
	
DELETE FROM Matchs;
DELETE FROM Joueur;
DELETE FROM Equipe;
DELETE FROM Poste;
DELETE FROM Journee;

ALTER SEQUENCE cleJournee RESTART WITH 1;
ALTER SEQUENCE cleJoueur RESTART WITH 1;

INSERT INTO Journee VALUES(nextval('cleJournee'),'04/02/2023');

INSERT INTO Equipe VALUES('France','Stade de France');
INSERT INTO Equipe VALUES('Angleterre','Stade de Twickenham');
INSERT INTO Equipe VALUES('Italie','Stade Olympique');
INSERT INTO Equipe VALUES('Irlande','Aviva Stadium');
INSERT INTO Equipe VALUES('Pays de Galles','Millennium Stadium');
INSERT INTO Equipe VALUES('Ecosse','Murrayfield Stadium');

INSERT INTO Matchs VALUES('Pays de Galles','Irlande','Millennium Stadium',10,34,1,NULL);
INSERT INTO Matchs VALUES('Angleterre','Ecosse','Stade de Twickenham',23,29,1,NULL);
INSERT INTO Matchs VALUES('Italie','France','Stade Olympique',24,29,1,NULL);

SELECT * FROM F_question7(1);