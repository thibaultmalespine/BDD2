DROP TRIGGER q6 ON Matchs;
DROP FUNCTION F_question6();

CREATE OR REPLACE FUNCTION F_question6() RETURNS TRIGGER AS $$
DECLARE
	stadeEqu1 Equipe.stadeEquipe%TYPE;
	stadeEqu2 Equipe.stadeEquipe%TYPE;
BEGIN
	SELECT INTO stadeEqu1 stadeEquipe
	FROM Equipe
	WHERE nomEquipe = NEW.equipe1;
	SELECT INTO stadeEqu2 stadeEquipe
	FROM Equipe
	WHERE nomEquipe = NEW.equipe2;
	IF NEW.leLieu = stadeEqu1 OR NEW.leLieu = stadeEqu2 THEN
		RETURN NEW;
	ELSE
		RAISE NOTICE 'le lieu du match doit etre celui de l une des 2 equipes';
		RETURN NULL;
	END IF;
END; $$LANGUAGE 'plpgsql';

CREATE TRIGGER q6
	BEFORE INSERT OR UPDATE ON Matchs
	FOR EACH ROW
	EXECUTE PROCEDURE F_question6();
	

-- on vide les tables avant les tests
	
DELETE FROM Matchs;
DELETE FROM Joueur;
DELETE FROM Equipe;
DELETE FROM Poste;
DELETE FROM Journee;

ALTER SEQUENCE cleJournee RESTART WITH 1;
ALTER SEQUENCE cleJoueur RESTART WITH 1;

INSERT INTO Journee VALUES(nextval('cleJournee'),'04/02/2023');

INSERT INTO Equipe VALUES('France','Stade de France');
INSERT INTO Equipe VALUES('Angleterre','Stade de Twickenham');
INSERT INTO Equipe VALUES('Italie','Stade Olympique');
INSERT INTO Equipe VALUES('Irlande','Aviva Stadium');
INSERT INTO Equipe VALUES('Pays de Galles','Millennium Stadium');
INSERT INTO Equipe VALUES('Ecosse','Murrayfield Stadium');




-- une insertion qui passe

INSERT INTO Matchs VALUES('Pays de Galles','Irlande','Millennium Stadium',10,34,1,NULL);

-- une insertion qui passe pas

INSERT INTO Matchs VALUES('Angleterre','Italie','Stade de France',23,29,1,NULL);

SELECT * FROM Matchs;
