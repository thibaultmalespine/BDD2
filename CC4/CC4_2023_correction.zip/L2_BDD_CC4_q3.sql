DROP VIEW q3;
CREATE VIEW q3 AS(
SELECT uneJournee
FROM Matchs
GROUP BY uneJournee
HAVING COUNT(*) != 3
);

DELETE FROM Matchs;
DELETE FROM Joueur;
DELETE FROM Equipe;
DELETE FROM Poste;
DELETE FROM Journee;

ALTER SEQUENCE cleJournee RESTART WITH 1;
ALTER SEQUENCE cleJoueur RESTART WITH 1;

INSERT INTO Journee VALUES(nextval('cleJournee'),'04/02/2023');
INSERT INTO Journee VALUES(nextval('cleJournee'),'11/02/2023');

INSERT INTO Equipe VALUES('France','Stade de France');
INSERT INTO Equipe VALUES('Angleterre','Stade de Twickenham');
INSERT INTO Equipe VALUES('Italie','Stade Olympique');
INSERT INTO Equipe VALUES('Irlande','Aviva Stadium');
INSERT INTO Equipe VALUES('Pays de Galles','Millennium Stadium');
INSERT INTO Equipe VALUES('Ecosse','Murrayfield Stadium');

INSERT INTO Matchs VALUES('Pays de Galles','Irlande','Millennium Stadium',10,34,1,NULL);
INSERT INTO Matchs VALUES('Angleterre','Ecosse','Stade de Twickenham',23,29,1,NULL);
INSERT INTO Matchs VALUES('Italie','France','Stade Olympique',24,29,1,NULL);

INSERT INTO Matchs VALUES('Irlande','France','Aviva Stadium',32,19,2,NULL);
INSERT INTO Matchs VALUES('Ecosse','Pays de Galles','Murrayfield Stadium',35,7,2,NULL);

SELECT * FROM q3; --doit retourner la journee no2
