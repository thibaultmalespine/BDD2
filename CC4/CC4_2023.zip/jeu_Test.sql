-- on vide les tables avant les tests
	
DELETE FROM Matchs;
DELETE FROM Joueur;
DELETE FROM Equipe;
DELETE FROM Poste;
DELETE FROM Journee;

ALTER SEQUENCE cleJournee RESTART WITH 1;
ALTER SEQUENCE cleJoueur RESTART WITH 1;

INSERT INTO Journee VALUES(nextval('cleJournee'),'04/02/2023');
INSERT INTO Journee VALUES(nextval('cleJournee'),'11/02/2023');
INSERT INTO Journee VALUES(nextval('cleJournee'),'25/02/2023');
INSERT INTO Journee VALUES(nextval('cleJournee'),'11/03/2023');
INSERT INTO Journee VALUES(nextval('cleJournee'),'18/02/2023');

INSERT INTO Poste VALUES('pilier');
INSERT INTO Poste VALUES('talonneur');
INSERT INTO Poste VALUES('2 eme ligne');
INSERT INTO Poste VALUES('3 eme ligne');
INSERT INTO Poste VALUES('demi de melee');
INSERT INTO Poste VALUES('demi d ouverture');
INSERT INTO Poste VALUES('centre');
INSERT INTO Poste VALUES('ailier');
INSERT INTO Poste VALUES('arriere');

INSERT INTO Equipe VALUES('France','Stade de France');
INSERT INTO Equipe VALUES('Angleterre','Stade de Twickenham');
INSERT INTO Equipe VALUES('Italie','Stade Olympique');
INSERT INTO Equipe VALUES('Irlande','Aviva Stadium');
INSERT INTO Equipe VALUES('Pays de Galles','Millennium Stadium');
INSERT INTO Equipe VALUES('Ecosse','Murrayfield Stadium');

INSERT INTO Joueur VALUES(NEXTVAL('cleJoueur'),'Baile','Cyril','pilier','France');
INSERT INTO Joueur VALUES(NEXTVAL('cleJoueur'),'Marchand','Julien','talonneur','France');
INSERT INTO Joueur VALUES(NEXTVAL('cleJoueur'),'Flamand','Thibaut','2 eme ligne','France');
INSERT INTO Joueur VALUES(NEXTVAL('cleJoueur'),'Cros','Francois','3 eme ligne','France');
INSERT INTO Joueur VALUES(NEXTVAL('cleJoueur'),'Dupond','Antoine','demi de melee','France');
INSERT INTO Joueur VALUES(NEXTVAL('cleJoueur'),'Jalibert','Matthieu','demi d ouverture','France');
INSERT INTO Joueur VALUES(NEXTVAL('cleJoueur'),'Fickou','Gael','centre','France');
INSERT INTO Joueur VALUES(NEXTVAL('cleJoueur'),'Penaud','Damian','ailier','France');
INSERT INTO Joueur VALUES(NEXTVAL('cleJoueur'),'Ramos','Thomas','arriere','France');

INSERT INTO Joueur VALUES(NEXTVAL('cleJoueur'),'Cole','Dan','pilier','Angleterre');
INSERT INTO Joueur VALUES(NEXTVAL('cleJoueur'),'George','Jamie','talonneur','Angleterre');
INSERT INTO Joueur VALUES(NEXTVAL('cleJoueur'),'Hill','Jonny','2 eme ligne','Angleterre');
INSERT INTO Joueur VALUES(NEXTVAL('cleJoueur'),'Willis','Jack','3 eme ligne','Angleterre');
INSERT INTO Joueur VALUES(NEXTVAL('cleJoueur'),'Mitchell','Alex','demi de melee','Angleterre');
INSERT INTO Joueur VALUES(NEXTVAL('cleJoueur'),'Farrell','Owen','demi d ouverture','Angleterre');
INSERT INTO Joueur VALUES(NEXTVAL('cleJoueur'),'Marchant','Joe','centre','Angleterre');
INSERT INTO Joueur VALUES(NEXTVAL('cleJoueur'),'Watson','Anthony','ailier','Angleterre');
INSERT INTO Joueur VALUES(NEXTVAL('cleJoueur'),'Steward','Freddie','arriere','Angleterre');

INSERT INTO Joueur VALUES(NEXTVAL('cleJoueur'),'Bhatti','Jamie','pilier','Ecosse');
INSERT INTO Joueur VALUES(NEXTVAL('cleJoueur'),'Brown','Fraser','talonneur','Ecosse');
INSERT INTO Joueur VALUES(NEXTVAL('cleJoueur'),'Gray','Richie','2 eme ligne','Ecosse');
INSERT INTO Joueur VALUES(NEXTVAL('cleJoueur'),'Ritchie','Jamie','3 eme ligne','Ecosse');
INSERT INTO Joueur VALUES(NEXTVAL('cleJoueur'),'Price','Ali','demi de melee','Ecosse');
INSERT INTO Joueur VALUES(NEXTVAL('cleJoueur'),'Russel','Finn','demi d ouverture','Ecosse');
INSERT INTO Joueur VALUES(NEXTVAL('cleJoueur'),'Harris','Chris','centre','Ecosse');
INSERT INTO Joueur VALUES(NEXTVAL('cleJoueur'),'Maitland','Sean','ailier','Ecosse');
INSERT INTO Joueur VALUES(NEXTVAL('cleJoueur'),'Hogg','Stuart','arriere','Ecosse');

INSERT INTO Joueur VALUES(NEXTVAL('cleJoueur'),'Brown','Leon','pilier','Pays de Galles');
INSERT INTO Joueur VALUES(NEXTVAL('cleJoueur'),'Owens','Ken','talonneur','Pays de Galles');
INSERT INTO Joueur VALUES(NEXTVAL('cleJoueur'),'Beard','Adam','2 eme ligne','Pays de Galles');
INSERT INTO Joueur VALUES(NEXTVAL('cleJoueur'),'Reffell','Tommy','3 eme ligne','Pays de Galles');
INSERT INTO Joueur VALUES(NEXTVAL('cleJoueur'),'Hardy','Kieran','demi de melee','Pays de Galles');
INSERT INTO Joueur VALUES(NEXTVAL('cleJoueur'),'Biggar','Dan','demi d ouverture','Pays de Galles');
INSERT INTO Joueur VALUES(NEXTVAL('cleJoueur'),'Grady','Mason','centre','Pays de Galles');
INSERT INTO Joueur VALUES(NEXTVAL('cleJoueur'),'Adams','Josh','ailier','Pays de Galles');
INSERT INTO Joueur VALUES(NEXTVAL('cleJoueur'),'Williams','Liam','arriere','Pays de Galles');

INSERT INTO Joueur VALUES(NEXTVAL('cleJoueur'),'Healy','Cian','pilier','Irlande');
INSERT INTO Joueur VALUES(NEXTVAL('cleJoueur'),'Herring','Rob','talonneur','Irlande');
INSERT INTO Joueur VALUES(NEXTVAL('cleJoueur'),'Henderson','Lain','2 eme ligne','Irlande');
INSERT INTO Joueur VALUES(NEXTVAL('cleJoueur'),'Baird','Ryan','3 eme ligne','Irlande');
INSERT INTO Joueur VALUES(NEXTVAL('cleJoueur'),'Blade','Caolin','demi de melee','Irlande');
INSERT INTO Joueur VALUES(NEXTVAL('cleJoueur'),'Sexton','Jonathan','demi d ouverture','Irlande');
INSERT INTO Joueur VALUES(NEXTVAL('cleJoueur'),'Aki','Bundee','centre','Irlande');
INSERT INTO Joueur VALUES(NEXTVAL('cleJoueur'),'Earls','Keith','ailier','Irlande');
INSERT INTO Joueur VALUES(NEXTVAL('cleJoueur'),'Keenan','Hugo','arriere','Irlande');

INSERT INTO Joueur VALUES(NEXTVAL('cleJoueur'),'Ceccarelli','Pietro','pilier','Italie');
INSERT INTO Joueur VALUES(NEXTVAL('cleJoueur'),'Bigi','Lucas','talonneur','Italie');
INSERT INTO Joueur VALUES(NEXTVAL('cleJoueur'),'Cannone','Niccolo','2 eme ligne','Italie');
INSERT INTO Joueur VALUES(NEXTVAL('cleJoueur'),'Lamaro','Michele','3 eme ligne','Italie');
INSERT INTO Joueur VALUES(NEXTVAL('cleJoueur'),'Garbisi','Alessandro','demi de melee','Italie');
INSERT INTO Joueur VALUES(NEXTVAL('cleJoueur'),'Allan','Tommaso','demi d ouverture','Italie');
INSERT INTO Joueur VALUES(NEXTVAL('cleJoueur'),'Menoncello','Tommaso','centre','Italie');
INSERT INTO Joueur VALUES(NEXTVAL('cleJoueur'),'Bruno','Pierre','ailier','Italie');
INSERT INTO Joueur VALUES(NEXTVAL('cleJoueur'),'Capuozzo','Ange','arriere','Italie');

INSERT INTO Matchs VALUES('Pays de Galles','Irlande','Millennium Stadium',10,34,1,NULL);
INSERT INTO Matchs VALUES('Angleterre','Ecosse','Stade de Twickenham',23,29,1,NULL);
INSERT INTO Matchs VALUES('Italie','France','Stade Olympique',24,29,1,NULL);

INSERT INTO Matchs VALUES('Irlande','France','Aviva Stadium',32,19,2,NULL);
INSERT INTO Matchs VALUES('Ecosse','Pays de Galles','Murrayfield Stadium',35,7,2,NULL);
INSERT INTO Matchs VALUES('Angleterre','Italie','Stade de Twickenham',31,14,2,NULL);

INSERT INTO Matchs VALUES('Italie','Irlande','Stade Olympique',20,34,3,NULL);
INSERT INTO Matchs VALUES('Pays de Galles','Angleterre','Millennium Stadium',10,20,3,NULL);
INSERT INTO Matchs VALUES('France','Ecosse','Stade de France',32,21,3,NULL);

INSERT INTO Matchs VALUES('Italie','Pays de Galles','Stade Olympique',17,29,4,NULL);
INSERT INTO Matchs VALUES('Angleterre','France','Stade de Twickenham',10,53,4,NULL);
INSERT INTO Matchs VALUES('Ecosse','Irlande','Murrayfield Stadium',7,22,4,NULL);

INSERT INTO Matchs VALUES('Ecosse','Italie','Murrayfield Stadium',26,14,5,NULL);
INSERT INTO Matchs VALUES('France','Pays de Galles','Stade de France',41,28,5,NULL);
INSERT INTO Matchs VALUES('Irlande','Angleterre','Aviva Stadium',29,16,5,NULL);