DROP TRIGGER q4 ON Matchs;
DROP FUNCTION F_question4();

CREATE OR REPLACE FUNCTION F_question4() RETURNS TRIGGER AS $$
BEGIN
	IF UPPER(NEW.equipe1) = UPPER(NEW.equipe2) THEN
		RAISE NOTICE 'un match doit concerner deux equipes differentes';
		RETURN NULL;
	ELSE
		RETURN NEW;
	END IF;
END; $$LANGUAGE 'plpgsql';

CREATE TRIGGER q4
	BEFORE INSERT OR UPDATE ON Matchs
	FOR EACH ROW
	EXECUTE PROCEDURE F_question4();
	

-- on vide les tables avant les tests
	
DELETE FROM Matchs;
DELETE FROM Joueur;
DELETE FROM Equipe;
DELETE FROM Poste;
DELETE FROM Journee;

ALTER SEQUENCE cleJournee RESTART WITH 1;
ALTER SEQUENCE cleJoueur RESTART WITH 1;

INSERT INTO Journee VALUES(nextval('cleJournee'),'04/02/2023');

INSERT INTO Equipe VALUES('France','Stade de France');
INSERT INTO Equipe VALUES('Angleterre','Stade de Twickenham');
INSERT INTO Equipe VALUES('Italie','Stade Olympique');
INSERT INTO Equipe VALUES('Irlande','Aviva Stadium');
INSERT INTO Equipe VALUES('Pays de Galles','Millennium Stadium');
INSERT INTO Equipe VALUES('Ecosse','Murrayfield Stadium');




-- une insertion qui passe

INSERT INTO Matchs VALUES('Pays de Galles','Irlande','Millennium Stadium',10,34,1,NULL);

-- une insertion qui passe pas

INSERT INTO Matchs VALUES('Angleterre','Angleterre','Stade de Twickenham',23,29,1,NULL);

SELECT * FROM Matchs;
