\echo [INFO] Debut du script

-- 
\echo [INFO] Creation de la base de donnees tournoi6nations
DROP DATABASE IF EXISTS tournoi6nations;
CREATE DATABASE tournoi6nations ENCODING 'UTF8';

\echo [INFO] Connexion a la nouvelle base de donnees tournoi6nations

\c tournoi6nations

SET DATESTYLE='DMY';

DROP TABLE IF EXISTS Matchs;

DROP TABLE IF EXISTS Joueur;

DROP TABLE IF EXISTS Equipe;

DROP TABLE IF EXISTS Poste;

DROP TABLE IF EXISTS Journee;


CREATE TABLE Journee
   (
    noJournee INT  PRIMARY KEY,
    dateJ DATE NOT NULL
   ) ;
   
CREATE TABLE Poste
   (
    nomPoste VARCHAR(40)  PRIMARY KEY
	CONSTRAINT ckNomPoste CHECK (nomPoste = 'pilier' OR nomPoste = 'talonneur' OR nomPoste = '2 eme ligne'
	OR nomPoste = '3 eme ligne' OR nomPoste = 'demi de melee' OR nomPoste = 'demi d ouverture'
	OR nomPoste = 'centre' OR nomPoste = 'ailier' OR nomPoste = 'arriere')
   ) ;


CREATE TABLE Equipe
   (
    nomEquipe VARCHAR(40)  PRIMARY KEY,
    stadeEquipe VARCHAR(40) UNIQUE
   ) ;
   
CREATE TABLE Joueur
   (
    idJoueur INT  PRIMARY KEY,
	nomJ VARCHAR(40),
	prenomJ VARCHAR(40),
	lePoste VARCHAR(40) NOT NULL, 
	lEquipe VARCHAR(40) NOT NULL
   ) ;

CREATE TABLE Matchs(
	equipe1 VARCHAR(40) REFERENCES Equipe(nomEquipe),
	equipe2 VARCHAR(40) REFERENCES Equipe(nomEquipe),
	leLieu VARCHAR(40) NOT NULL
	REFERENCES Equipe(stadeEquipe),
	score1 INT,
	score2 INT,
	uneJournee INT NOT NULL
	CONSTRAINT fkMatchsJournee REFERENCES Journee(noJournee),
	h_du_Match INT REFERENCES Joueur(idJoueur)
	);
   
   
   
DROP SEQUENCE IF EXISTS cleJournee;
CREATE SEQUENCE cleJournee MINVALUE 1;

DROP SEQUENCE IF EXISTS cleJoueur;
CREATE SEQUENCE cleJoueur MINVALUE 1;




	
